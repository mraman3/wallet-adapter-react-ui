import type { FC } from 'react';
export interface WalletModalProps {
    className?: string;
    container?: string;
}
export declare const WalletModal: FC<WalletModalProps>;
//# sourceMappingURL=WalletModal.d.ts.map