import React from 'react';
import type { ButtonProps } from './Button.js';
export declare function WalletDisconnectButton(props: ButtonProps): React.JSX.Element;
//# sourceMappingURL=WalletDisconnectButton.d.ts.map