import type { FC } from 'react';
import type { ButtonProps } from './Button.js';
export declare const WalletModalButton: FC<ButtonProps>;
//# sourceMappingURL=WalletModalButton.d.ts.map