import type { FC } from 'react';
export declare const WalletSVG: FC;
//# sourceMappingURL=WalletSVG.d.ts.map