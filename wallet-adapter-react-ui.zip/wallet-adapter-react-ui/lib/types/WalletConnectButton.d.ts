import React from 'react';
import type { ButtonProps } from './Button.js';
export declare function WalletConnectButton(props: ButtonProps): React.JSX.Element;
//# sourceMappingURL=WalletConnectButton.d.ts.map