import React from 'react';
import type { ButtonProps } from './Button.js';
export declare function WalletMultiButton(props: ButtonProps): React.JSX.Element;
//# sourceMappingURL=WalletMultiButton.d.ts.map